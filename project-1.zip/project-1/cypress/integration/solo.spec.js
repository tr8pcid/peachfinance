describe('Successful Login', () => {
    const Email = 'auto.user+bo-qbwe-9e2b@peachfinance.com'
    const Password = 'hello12345'
    beforeEach(() => {
        cy.visit("https://peach-borrower.peach-dev.finance/login")
       cy.contains("Email")
       cy.contains('Password')
    })
})
    describe('Verifying sign out', () => {

        it('Sign out', () => {
            cy.visit("/login")
         
            })
        })
        


