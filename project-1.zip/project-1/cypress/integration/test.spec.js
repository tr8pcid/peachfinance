describe('Successful Login', () => {
        it('Reaching login page', () => {
            cy.visit('/login')
        })
        beforeEach(() => {
            cy.login('auto.user+bo-qbwe-9e2b@peachfinance.com', 'hello123453')

    })

describe('Correct and Incorrect Payments', () => {

        it('$2 Payment', () => {
            cy.wait(1*1000)
            cy.contains("Make a payment").click()
            cy.wait(2*1000)
            cy.contains('Today').click()
            cy.contains("22").click()
            cy.wait(3*1000)
            cy.contains("Other amount").click()
            cy.get("input[placeholder=\"0.00\"]").type("2")
            cy.contains('Select payment method').click()
            cy.wait(2*1000)
            cy.contains('Debit Card *4444').click()
            cy.contains('Continue').click()
            cy.get('[data-testid=modal-content]').should('exist')
            cy.get('[data-cy=modal-submit]').click()
            cy.wait(50*1000)
            cy.get('[data-cy=submit]').click()
      
        })    
        it('$0 Payment wont process', () => {
            cy.visit('/activity')
            cy.contains("Email").type('auto.user+bo-qbwe-9e2b@peachfinance.com')
            cy.contains("Password").type('hello12345')
            cy.contains("Continue").click()
            cy.wait(1*1000)
            cy.contains("Make a payment").click()
            cy.wait(2*1000)
            cy.contains('Today').click()
            cy.contains("20").click()
            cy.contains("Other amount").click()
            cy.get("input[placeholder=\"0.00\"]").type("0")
            cy.contains('Select payment method').click()
            cy.wait(2*1000)
            cy.contains('Debit Card *4444').click()
            cy.contains('Continue').should('exist').should('be.disabled')
            //Continue button should be disabled due value = 0 wont process
       
        })
        it('$10000 Payment wont process', () => {
            //cy.contains("Account Login")
            //cy.contains("Email").type('auto.user+bo-qbwe-9e2b@peachfinance.com')
            //cy.contains("Password").type('hello12345')
            //cy.contains("Continue").click()
            //cy.wait(1*1000)
            //cy.contains("Make a payment").click()
            //cy.wait(2*1000)
            cy.contains('Today').click()
            cy.contains("20").click()
            cy.contains("Other amount").click()
            cy.get("input[placeholder=\"0.00\"]").type("10000")
            cy.contains('Debit Card *4444').click()
            cy.wait(2*1000)
            cy.contains('Debit Card *4444').click()
            cy.contains('Continue').click()
            cy.contains('Payment amount must be less than or equal to the loan remaining balance').should("exist")         
            cy.contains('Continue').click()


            })
        })

describe('Adding correct payment method', () => {

        it('Adding correct debit card', () => {
            cy.visit("/login")
            cy.contains("Email").type('auto.user+bo-qbwe-9e2b@peachfinance.com')
            cy.contains("Password").type('hello12345')
            cy.contains("Continue").click()
            cy.wait(1*1000)
            cy.contains("Loan options").click()
            cy.wait(1*1000)
            cy.contains('Manage payment methods').click()
            cy.contains("Add payment method").click()
            cy.contains ('span[class="btn-label"]', 'Card').click()
            cy.contains("FIRST NAME").click().type("Sal")
            cy.contains("LAST NAME").click().type("Houdini")
            cy.contains("CARD NUMBER").click().type("5555555555554443")
            cy.get('label[class="material-styled-animation borderless"]').contains('EXP').click().type('0226')
            cy.contains("CVC").click().type("456")
            cy.contains("ZIP").click().type("12345")
            cy.get('[data-cy=submit]').click()
        
            })
        })
        
describe('Verifying incorrect payment method', () => {

        it('Adding incorrect debit card', () => {
            cy.visit("/login")
            cy.contains("Email").type('auto.user+bo-qbwe-9e2b@peachfinance.com')
            cy.contains("Password").type('hello12345')
            cy.contains("Continue").click()
            cy.wait(1*1000)
            cy.contains("Loan options").click()
            cy.wait(1*1000)
            cy.contains('Manage payment methods').click()
            cy.contains("Add payment method").click()
            cy.contains ('span[class="btn-label"]', 'Card').click()
            cy.contains("FIRST NAME").click().type("Sal")
            cy.contains("LAST NAME").click().type("Houdini")
            cy.contains("CARD NUMBER").click().type("0000000000000000")
            cy.get('label[class="material-styled-animation borderless"]').contains('EXP').click().type('0226')
            cy.contains("CVC").click().type("123")
            cy.contains("ZIP").click().type("12345")
            cy.get('[data-cy=submit]').click()
            cy.contains("CARD NUMBER").should(
                    'not.have.css',
                    '-webkit-text-fill-color',
                    'rgb(153, 157, 162)'
                                            )
            cy.wait(5*1000)
        })
        })

describe('Verifying autopay can be updated', () => {

        it('Changing autopay time', () => {
            cy.visit("/login")
            cy.contains("Email").type('auto.user+bo-qbwe-9e2b@peachfinance.com')
            cy.contains("Password").type('hello12345')
            cy.contains("Continue").click()
            cy.wait(4*1000)
            cy.contains("Loan options").click()
            cy.wait(1*1000)
            cy.contains('Manage Autopay').click()
            cy.wait(1*1000)
            cy.contains('3rd').click()
            cy.contains('2nd').click()
            cy.contains('View full payment schedule').should('exist')
            cy.contains('Update Autopay').click()
            cy.wait(15*1000)
            cy.contains('Your Autopay settings have been updated.').should('exist')
            cy.contains('Done').click()
                
                })
            })
        
        
        

describe('Changing due date should cancel autopay', () => {

        it('Changing due date does not turn off autopay', () => {
            cy.visit("/login")
            cy.contains("Email").type('auto.user+bo-qbwe-9e2b@peachfinance.com')
            cy.contains("Password").type('hello12345')
            cy.contains("Continue").click()
            cy.wait(4*1000)
            cy.contains("Loan options").click()
            cy.wait(1*1000)
            cy.contains('Change due date').click()
            cy.contains('Change due date').should('exist')
            cy.contains('Select frequency').click()
            cy.contains('Monthly').click()
            cy.contains('Select frequency').click()
            cy.contains('Twice a month').click()
            cy.contains('Select range').click()
            cy.contains('5th and 20th').click()
            cy.wait(3*1000)
            cy.contains('Update due dates').click()
            cy.contains('Done').click()
            //Redirected back to activity page when sucessfull
            cy.contains('button[class="Button__StyledButton-sc-1irh7c3-0 cntfG button border-none"]', 'Autopay on').should('exist')
            //Autopay is still on therefore test is a pass
            //This is a bug
            })
        })
        
describe('Viewing payoff statement', () => {

        it('Accessing payoff statement successfull', () => {
            cy.visit("/login")
            cy.contains("Email").type('auto.user+bo-qbwe-9e2b@peachfinance.com')
            cy.contains("Password").type('hello12345')
            cy.contains("Continue").click()
            cy.wait(4*1000)
            cy.contains("Loan options").click()
            cy.wait(1*1000)
            cy.contains('Get payoff statement').click()
            cy.contains('View').click()
            cy.contains('Submit').click()
            cy.wait(5*1000)
            //Statement window shoould pop up
            cy.contains('Payoff statement successfully created.').should('exist')
            cy.contains('Done').click()
            })
        })
        
describe('Changeing nickname for account', () => {

        it('Editing nickname', () => {
            cy.visit("/login")
            cy.contains("Email").type('auto.user+bo-qbwe-9e2b@peachfinance.com')
            cy.contains("Password").type('hello12345')
            cy.contains("Continue").click()
            cy.wait(4*1000)
            cy.contains("Loan options").click()
            cy.wait(1*1000)
            cy.contains('Change nickname').click()
            cy.get('.editable-field').click().clear().type('New nickname 2')
            cy.contains('Update').click()
            cy.contains('New nickname 3').should('exist')
            //Use a new nickname to reuse code//
            })
        })
describe('Verifying sign out', () => {

        it('Sign out', () => {
            cy.visit("/login")
            cy.contains("Email").type('auto.user+bo-qbwe-9e2b@peachfinance.com')
            cy.contains("Password").type('hello12345')
            cy.contains("Continue").click()
            cy.wait(3*1000)
            cy.contains('Auto User').click()
            cy.contains('Sign out').click()
            cy.contains('Account Login').should('exist')
                
            })
        })
        
    })
